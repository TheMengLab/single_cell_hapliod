#!/bin/bash

id=GSM2219497_Cell_1_contact_pairs.txt
cp ../../${id} .
replace  X 20 -- ${id}
replace chr "" -- ${id}
grep -v A ${id} > test.dat
mv test.dat ${id}

for i in `seq 1 20`
do
awk -v ID=${i} '{if(($1==ID)&&($3==ID)) print $2,$4}' ${id} > ${i}_${i}.dat
echo $i
echo -e ${i}_${i}.dat '\n' intra_${i}_1kb.dat | ./gettargetcontact.o 
#Input filename for contact file list:
#Input the filename for output:

done



for i in `seq 1 20`
do
for j in `seq $[i+1] 20`
do
awk -v ID=${i} -v ID2=${j} '{if(($1==ID)&&($3==ID2)) print $2,$4}' ${id} > ${i}_${j}.dat
awk -v ID=${i} -v ID2=${j} '{if(($1==ID2)&&($3==ID)) print $4,$2}' ${id} >> ${i}_${j}.dat
echo -e ${i}_${j}.dat '\n' inter_${i}_${j}_1kb.dat | ./gettargetcontact.o 
#Input filename for contact file list:
#Input the filename for output:
echo $i $j
done
done



#awk '{print $1,$3}' ${id} | sort -u > check.dat


#for i in `seq 1 `
