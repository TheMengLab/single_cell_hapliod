#!/bin/bash

sid=1

for i in `seq 1 20`
do
bash do_intra.sh $sid $i
done


bash do_inter.sh $sid

