#!/bin/bash

sid=$1
id=$2
#time echo -e ../../data/filter/1/intra_1_1kb.dat '\n' 500 '\n' matrix.dat | ./getdistmatrix.o
#time echo -e ../../data/filter/1/intra_19_1kb.dat '\n' 50 '\n' matrix.dat '\n' contactbool.dat | ./getdistmatrix.o 
#time echo -e ../../data/filter/1/intra_19_1kb.dat '\n' 50 '\n' matrix.dat '\n' contactmatrix.dat | ./getcontactmatrix.o 
#time echo -e ../../data/filter/1/intra_19_1kb.dat '\n' 50 '\n' matrix.dat '\n' contactmatrix.dat '\n' assign.dat | ./getcontactmatrix_assign.o 
#list="
#1600
#800
#400
#200
#100
#50
#"
list="
1280
640
320
160
80
40
20
10
"

for res in $list
do
len=`cat ../chrlen/len${id}.dat`
echo $len
time echo -e ../1kb_prepare/intra_${id}_1kb.dat '\n' ${res} '\n' ${len} '\n' contactmatrix${res}_chr${id}.dat '\n' assign${res}_chr${id}.dat | ./getcontactmatrix_assign_intra_len.o > target${res}_chr${id}.dat
#Input filename for original data:
#Input the binsize for the system(in the unit of kb):
#Input the filename for output:
#Input filename for contact bool:
grep target target${res}_chr${id}.dat | awk '{print $2,$3,$4}' > test.dat
mv test.dat target${res}_chr${id}.dat
done

#rm contactmatrix*.dat

list2="
320
160
80
40
20
10
"
#list2="
#400
#200
#100
#50
#"

for res in $list2
do
echo -e assign${res}_chr${id}.dat '\n' assign640_chr${id}.dat '\n' test.dat | ./modifyassign.o 
#Input filename for assignment of target resolution:
#Input filename for reference assignment:
#Input filename for output:
#ratio:8 7.984375
mv test.dat assign${res}_chr${id}.dat

done

