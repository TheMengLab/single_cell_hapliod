#!/bin/bash


cd contact/1kb_prepare/
bash do.sh
cd ../10kb_target/
bash doall.sh
cd contactall/
bash do.sh
cd ../../..
