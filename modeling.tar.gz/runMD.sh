#!/bin/bash
cd MD_simulation/replica/

for i in `seq 1 4`
do
cd $i
nohup bash doall.sh &
cd ..
done

cd ..

