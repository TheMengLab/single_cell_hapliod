#!/bin/bash

bash do.sh 3
bash do1.sh
bash do2.sh
bash do3.sh
bash do4.sh
bash do5.sh
bash do6.sh
bash do7.sh
